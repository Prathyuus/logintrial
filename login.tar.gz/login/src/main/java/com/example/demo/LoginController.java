package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class LoginController {
@GetMapping("/login/uname/{uname}/pwd/{pwd}")
public LoginBean loginm(@PathVariable String uname, @PathVariable String pwd ) {
	System.out.println(uname+pwd);
	Map<String,String> urivariables = new HashMap<>() ;
	urivariables.put("uname",uname);
	urivariables.put("pwd", pwd);
	
	ResponseEntity<LoginBean> responseEntity = new RestTemplate().getForEntity("http://localhost:8002/login/uname/{uname}/pwd/{pwd}", LoginBean.class, urivariables);
	LoginBean response = responseEntity.getBody();
	
	return new LoginBean(response.getId(),uname,pwd,response.getIden());
	
}

}
