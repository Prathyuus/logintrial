package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IdentityRepository extends JpaRepository<Identity,Long>{
	Identity findByUnameAndPwd(String uname,String pwd);

}
