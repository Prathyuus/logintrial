package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.config.environment.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogindbController {
	
	@Autowired
	private IdentityRepository repository;
 @GetMapping("/logindb/uname/{uname}/pwd/{pwd}")
	public Identity retrieveId(@PathVariable String uname, @PathVariable String pwd) {
	Identity ident= repository.findByUnameAndPwd(uname,pwd);
	
	return ident;
 }
}
