insert into identity(id,uname,pwd,iden)
values(1001,'tata','passw',1);
insert into identity(id,uname,pwd,iden)
values(1002,'tat','pass',2);
insert into identity(id,uname,pwd,iden)
values(1003,'ta','pas',3);